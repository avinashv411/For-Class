package com.jspiders.jdbc.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Driver;

public class PreparedStatementExample1 
{
	public static void main(String[] args) 
	{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try 
		{
			//1. Load the Driver
			//Driver Class : com.mysql.jdbc.Driver
			Driver driverRef = new Driver();
			DriverManager.registerDriver(driverRef);
			
			//2. Get the DB Connection via Driver 
			String dbUrl = "jdbc:mysql://localhost:3306/BECM4_DB?user=j2ee&password=j2ee";
			con = DriverManager.getConnection(dbUrl);
			
			//3. Issue SQL Queries via Connection 
			String query = " select * from students_info " 
							+" where regno=? ";
			
			System.out.println("Query : "+query);
			
			pstmt = con.prepareStatement(query);
			
			String regNumber = args[0];
			int regNo = Integer.parseInt(regNumber);
			pstmt.setInt(1, regNo);
			
			rs = pstmt.executeQuery();
			
			//4. Process the Results returned by SQL Queries
			if(rs.next())
			{
				System.out.println("Reg. No. Found ...");
				int regNum = rs.getInt("regno");
				String fNM = rs.getString("firstname");
				String mNM = rs.getString("middlename");
				String lNM = rs.getString("lastname");
				
				System.out.println("Reg. No. : "+regNum);
				System.out.println("First Name : "+fNM);
				System.out.println("Middle Name : "+mNM);
				System.out.println("Last Name : "+lNM);
				
			}else{
				System.err.println("Reg. No. Does Not Exists !!!");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			//5. Close All JDBC Objects
			try 
			{
				if(con!=null){
					con.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(rs!=null){
					rs.close();
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}//End of outer try-catch block
		
	}//End of Main
}//End of Class
