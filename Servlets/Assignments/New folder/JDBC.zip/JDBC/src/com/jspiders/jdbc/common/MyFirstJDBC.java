package com.jspiders.jdbc.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Driver;

public class MyFirstJDBC 
{
	public static void main(String[] args) 
	{
		Connection con = null;
		ResultSet rs = null;
		Statement stmt = null;
		
		try 
		{
			/*
			 * 1. Load the Driver
			 * Driver Class : com.mysql.jdbc.Driver
			 */
			//First Way
			/*Driver driervRef = new Driver();
			DriverManager.registerDriver(driervRef);*/
			
			//Second Way
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			
			/*
			 * 2. Get the DB Connection via Driver
			 */
			String dbUrl = "jdbc:mysql://localhost:3306/BECM4_DB?user=j2ee&password=j2ee";
			con = DriverManager.getConnection(dbUrl);
			
			/*
			 * 3. Issue SQL Queries via Connection
			 */
			String query = "select * from students_info";
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			
			/*
			 * 4. Process the Results returned by SQL Queries
			 */
			while(rs.next())
			{
				int regNum = rs.getInt("regno");
				String fNM = rs.getString("firstname");
				String mNM = rs.getString("middlename");
				String lNM = rs.getString("lastname");
				
				System.out.println("Reg. No. : "+regNum);
				System.out.println("First Name : "+fNM);
				System.out.println("Middle Name : "+mNM);
				System.out.println("Last Name : "+lNM);
				System.out.println("---------------------");
			}//End of While
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			/*
			 * 5. Close All JDBC Objects
			 */
			try 
			{
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
				if(stmt!=null){
					stmt.close();
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}//End of outer try-catch
	}//End of Main
}//End of Class
