package com.jspiders.jdbc.common;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Driver;

public class CallableStatementExample 
{
	public static void main(String[] args) 
	{
		Connection con = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		
		try 
		{
			//1. Load the Driver
			//Driver Class : com.mysql.jdbc.Driver
			Driver driverRef = new Driver();
			DriverManager.registerDriver(driverRef);
			
			//2. Get the DB Connection via Driver 
			String dbUrl = "jdbc:mysql://localhost:3306/BECM4_DB?user=j2ee&password=j2ee";
			con = DriverManager.getConnection(dbUrl);
			
			//3. Issue SQL Queries via Connection 
			//String query = "call getAllStudents()";
			//String query = "call getStudentInfo(5)";
			//String query = "call getStudentInfo(?)";
			String query = "call studentUpSert(?,?,?,?)";
			cstmt = con.prepareCall(query);
			cstmt.setInt(1, Integer.parseInt(args[0]) );
			cstmt.setString(2, args[1]);
			cstmt.setString(3, args[2]);
			cstmt.setString(4, args[3]);
			boolean isDBresults = cstmt.execute();
			
			//4. Process the Results returned by SQL Queries
			if(isDBresults)
			{
				System.out.println("Result is of Type DB Results ...");
				rs = cstmt.getResultSet();
				while(rs.next())
				{
					int regNum = rs.getInt("regno");
					String fNM = rs.getString("firstname");
					String mNM = rs.getString("middlename");
					String lNM = rs.getString("lastname");
					
					System.out.println("Reg. No. : "+regNum);
					System.out.println("First Name : "+fNM);
					System.out.println("Middle Name : "+mNM);
					System.out.println("Last Name : "+lNM);
					System.out.println("---------------------");
				}//End of While
			}else{
				System.out.println("Result is of Type INT Count ...");
				int count = cstmt.getUpdateCount();
				System.out.println("Rows Affected : "+count);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			//5. Close All JDBC Objects
			try 
			{
				if(con!=null){
					con.close();
				}
				if(cstmt!=null){
					cstmt.close();
				}
				if(rs!=null){
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}//End of outer try-catch
	}//End of main
}//End of Class
