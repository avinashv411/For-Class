package com.jspiders.studentsapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspiders.studentsapp.dao.StudentDAO;
import com.jspiders.studentsapp.dao.StudentInfoBean;

public class LoginServlet extends HttpServlet
{
	RequestDispatcher dispatcher = null;
	
	@Override
	protected void doPost(HttpServletRequest req, 
						 HttpServletResponse resp)
	throws ServletException, IOException 
	{
		//1. Get the Form Data
		String regNum = req.getParameter("regno");
		String password = req.getParameter("pass");
		
		//2. Authenticate the Form Data
		StudentDAO dao = new StudentDAO();
		StudentInfoBean bean = dao.authenticate(regNum, password);
		
		String url = null;
		if(bean != null) {
			//Valid Credentials
			req.setAttribute("data", bean);
			url = "home";
		}else{
			req.setAttribute("errMsg", "In-Valid User Name & Password !!!");
			url = "loginErr";
		}
		//Forward the request to Generate Response
		dispatcher = req.getRequestDispatcher(url);
		dispatcher.forward(req, resp);

	}//End of doPost
}//End of Class
