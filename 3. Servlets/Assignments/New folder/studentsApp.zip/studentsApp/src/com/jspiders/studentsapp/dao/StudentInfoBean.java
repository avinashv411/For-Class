package com.jspiders.studentsapp.dao;

public class StudentInfoBean 
{
	private int regno;
	private String firstNM;
	private String middleNM;
	private String lastNM;
	
	private String gfirstNM;
	private String gmiddleNM;
	private String glastNM;
	
	private String isAdmin;
	private String password;
	
	public int getRegno() {
		return regno;
	}
	public void setRegno(int regno) {
		this.regno = regno;
	}
	public String getFirstNM() {
		return firstNM;
	}
	public void setFirstNM(String firstNM) {
		this.firstNM = firstNM;
	}
	public String getMiddleNM() {
		return middleNM;
	}
	public void setMiddleNM(String middleNM) {
		this.middleNM = middleNM;
	}
	public String getLastNM() {
		return lastNM;
	}
	public void setLastNM(String lastNM) {
		this.lastNM = lastNM;
	}
	public String getGfirstNM() {
		return gfirstNM;
	}
	public void setGfirstNM(String gfirstNM) {
		this.gfirstNM = gfirstNM;
	}
	public String getGmiddleNM() {
		return gmiddleNM;
	}
	public void setGmiddleNM(String gmiddleNM) {
		this.gmiddleNM = gmiddleNM;
	}
	public String getGlastNM() {
		return glastNM;
	}
	public void setGlastNM(String glastNM) {
		this.glastNM = glastNM;
	}
	public String getIsAdmin() {
		return isAdmin;
	}
	public void setIsAdmin(String isAdmin) {
		this.isAdmin = isAdmin;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
